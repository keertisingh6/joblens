"use client";

import { useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  BriefcaseBusiness,
  CheckCircle2,
  ClipboardCheck,
  Info,
  Loader2,
  RotateCcw,
  SearchCheck,
  Send,
  ShieldAlert,
  ShieldCheck
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

type Screen = "home" | "analyze" | "results";
type RiskLevel = "LOW" | "MEDIUM" | "HIGH";
type Severity = "high" | "medium" | "low";

type JobFormData = {
  jobDescription: string;
  companyName: string;
  recruiterEmail: string;
  applicationUrl: string;
};

type Finding = {
  title: string;
  why: string;
  action: string;
  severity: Severity;
};

type Indicator = {
  title: string;
  why: string;
  severity: Severity;
};

type AnalysisResult = {
  score: number;
  level: RiskLevel;
  indicators: Indicator[];
  recommendations: string[];
  findings: Finding[];
  positives: string[];
  summary: string;
  actions: string[];
};

const emptyForm: JobFormData = {
  jobDescription: "",
  companyName: "",
  recruiterEmail: "",
  applicationUrl: ""
};

const steps = [
  {
    title: "Submit",
    text: "Paste the job details, company name, recruiter email, and application link.",
    icon: Send
  },
  {
    title: "Analyze",
    text: "JobLens checks the posting against common recruitment scam indicators.",
    icon: SearchCheck
  },
  {
    title: "Decide",
    text: "Review the risk score, flagged warning signs, and safer next steps.",
    icon: ClipboardCheck
  }
];

const sampleWarnings = [
  {
    title: "Suspicious payment request",
    text: "The posting asks applicants to pay for onboarding, equipment, training, or document processing."
  },
  {
    title: "Recruiter information needs verification",
    text: "The recruiter details should be checked against the official company careers page or LinkedIn presence."
  },
  {
    title: "Suspicious application link",
    text: "The application URL does not clearly match a trusted company domain or known hiring platform."
  }
];

const knownCompanyDomains: Record<string, string[]> = {
  amazon: ["amazon.jobs", "amazon.com"],
  google: ["google.com", "abc.xyz"],
  microsoft: ["microsoft.com", "linkedin.com"],
  apple: ["apple.com"],
  meta: ["meta.com", "facebook.com"],
  netflix: ["netflix.com"],
  adobe: ["adobe.com"],
  salesforce: ["salesforce.com"],
  flipkart: ["flipkart.com"],
  tcs: ["tcs.com"],
  infosys: ["infosys.com"],
  wipro: ["wipro.com"]
};

const trustedHiringDomains = [
  "amazon.jobs",
  "greenhouse.io",
  "lever.co",
  "workdayjobs.com",
  "myworkdayjobs.com",
  "smartrecruiters.com",
  "ashbyhq.com",
  "linkedin.com",
  "naukri.com",
  "indeed.com"
];

const freeEmailDomains = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "proton.me", "icloud.com"];
const suspiciousDomains = [".xyz", ".top", ".click", ".work", ".loan", ".biz"];

function includesAny(text: string, patterns: RegExp[]) {
  return patterns.some((pattern) => pattern.test(text));
}

function clampScore(score: number) {
  return Math.max(0, Math.min(100, Math.round(score)));
}

function riskLevel(score: number): RiskLevel {
  if (score >= 70) return "HIGH";
  if (score >= 40) return "MEDIUM";
  return "LOW";
}

function getDomain(value: string) {
  const trimmed = value.trim().toLowerCase();
  if (!trimmed) return "";

  try {
    const withProtocol = trimmed.includes("://") ? trimmed : `https://${trimmed}`;
    return new URL(withProtocol).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

function getEmailDomain(email: string) {
  const parts = email.trim().toLowerCase().split("@");
  return parts.length === 2 ? parts[1] : "";
}

function normalizeCompany(companyName: string) {
  return companyName
    .toLowerCase()
    .replace(/\b(private|pvt|limited|ltd|inc|llc|corp|corporation|technologies|technology|solutions)\b/g, "")
    .replace(/[^a-z0-9]/g, "");
}

function domainMatchesCompany(domain: string, companyName: string) {
  const company = normalizeCompany(companyName);
  if (!domain || company.length < 3) return false;
  return domain.replace(/[^a-z0-9]/g, "").includes(company);
}

function getKnownDomains(companyName: string) {
  const company = normalizeCompany(companyName);
  return Object.entries(knownCompanyDomains).find(([key]) => company.includes(key))?.[1] ?? [];
}

function hasTrustedHiringDomain(domain: string) {
  return trustedHiringDomains.some((trustedDomain) => domain === trustedDomain || domain.endsWith(`.${trustedDomain}`));
}

function analyzeJob(data: JobFormData): AnalysisResult {
  const description = data.jobDescription.toLowerCase();
  const companyName = data.companyName.trim();
  const fullText = `${description} ${companyName.toLowerCase()} ${data.recruiterEmail.toLowerCase()} ${data.applicationUrl.toLowerCase()}`;
  const emailDomain = getEmailDomain(data.recruiterEmail);
  const applicationDomain = getDomain(data.applicationUrl);
  const knownDomains = getKnownDomains(companyName);
  const emailMatchesCompany = domainMatchesCompany(emailDomain, companyName);
  const applicationMatchesCompany = domainMatchesCompany(applicationDomain, companyName);
  const applicationIsKnownForCompany = knownDomains.some(
    (domain) => applicationDomain === domain || applicationDomain.endsWith(`.${domain}`)
  );
  const applicationIsTrusted = hasTrustedHiringDomain(applicationDomain);
  const findings: Finding[] = [];
  const positives: string[] = [];
  let score = 18;

  const addFinding = (finding: Finding, points: number) => {
    findings.push(finding);
    score += points;
  };

  const addPositive = (text: string, points: number) => {
    positives.push(text);
    score -= points;
  };

  if (includesAny(fullText, [/\b(registration|processing|security|application|training|onboarding)\s*(fee|fees|charge|charges)\b/, /\bdeposit\b/, /\bpay\s*(rs|inr|\u20b9|\$)?\s*\d+/, /\bpay\s*money\b/, /\bpay\s*to\s*apply\b/])) {
    addFinding(
      {
        title: "Payment request detected",
        why: "Legitimate employers rarely ask applicants to pay registration, processing, training, or security fees.",
        action: "Do not pay any amount. Verify the job directly through the company careers page.",
        severity: "high"
      },
      34
    );
  } else {
    addPositive("No payment request was detected in the submitted job details.", 8);
  }

  if (includesAny(fullText, [/\botp\b/, /\bpassword\b/, /\bbank\s*(pin|password|details|account)\b/, /\bcredit\s*card\b/, /\bdebit\s*card\b/, /\bupi\s*pin\b/, /\bnet\s*banking\b/])) {
    addFinding(
      {
        title: "Sensitive financial information requested",
        why: "Requests for OTPs, passwords, bank PINs, or financial credentials are strong scam indicators.",
        action: "Stop communication and never share financial credentials with a recruiter.",
        severity: "high"
      },
      36
    );
  }

  if (includesAny(fullText, [/\bpay\s*(to|and)\s*(get|secure|confirm)\s*(the\s*)?job\b/, /\bjob\s*(guaranteed|confirmation)\s*(after|once)\s*payment\b/])) {
    addFinding(
      {
        title: "Pay-to-get-job language",
        why: "A job offer should be based on qualifications and interviews, not payment.",
        action: "Treat the posting as high risk unless the company officially confirms it.",
        severity: "high"
      },
      30
    );
  }

  if (includesAny(fullText, [/\burgent\b/, /\bimmediate\s*(joining|selection|hiring)\b/, /\bact\s*now\b/, /\bwithin\s*(24|48)\s*hours\b/, /\blimited\s*slots?\b/, /\bfinal\s*chance\b/])) {
    addFinding(
      {
        title: "Extreme urgency or pressure",
        why: "Scam recruiters often pressure candidates to act quickly before they can verify the opportunity.",
        action: "Slow down and independently confirm the role before sharing information.",
        severity: "high"
      },
      18
    );
  }

  if (includesAny(fullText, [/\b(₹|rs\.?|inr|usd|\$)\s?\d{1,3}(,\d{2,3})*(\s?-\s?(₹|rs\.?|inr|usd|\$)?\s?\d{1,3}(,\d{2,3})*)?\s*(per\s*)?(day|week|month)\b/, /\b\d+\s*lpa\b/])) {
    const highSalary = includesAny(fullText, [/\b(₹|rs\.?|inr)\s?(1,?00,?000|[2-9]\d,?000|[1-9]\d,?00,?000)\s*(per\s*)?month\b/, /\b([3-9]\d|[1-9]\d{2})\s*lpa\b/, /\b(usd|\$)\s?([8-9]\d{3}|[1-9]\d{4,})\s*(per\s*)?month\b/]);
    const noExperience = includesAny(fullText, [/\bno\s*experience\s*(required|needed)\b/, /\bfreshers?\s*(welcome|can apply)\b/, /\bno\s*interview\b/]);

    if (highSalary && noExperience) {
      addFinding(
        {
          title: "Unusually high salary for low experience",
          why: "High pay paired with no experience requirements is a common lure in fake job postings.",
          action: "Compare the salary against similar roles and verify the employer before applying.",
          severity: "medium"
        },
        18
      );
    } else if (highSalary) {
      addFinding(
        {
          title: "Salary needs verification",
          why: "The compensation appears high enough to deserve extra verification against market rates.",
          action: "Check comparable salaries and confirm the range through official company channels.",
          severity: "medium"
        },
        10
      );
    }
  }

  if (includesAny(description, [/\bkindly\b.*\bwhatsapp\b/, /\bwhatsapp\s*(only|msg|message)\b/, /\btelegram\b/, /\btext\s*me\b/, /\bcall\s*now\b/])) {
    addFinding(
      {
        title: "Unusual communication method",
        why: "Recruitment that moves quickly to WhatsApp, Telegram, or informal messaging can be harder to verify.",
        action: "Ask for an official company email thread or a link to the official careers listing.",
        severity: "medium"
      },
      12
    );
  }

  if (companyName.length < 3 || includesAny(companyName.toLowerCase(), [/\bcompany\b/, /\bprivate\b/, /\bconfidential\b/, /\bnot disclosed\b/])) {
    addFinding(
      {
        title: "Missing or vague company information",
        why: "Vague company names make it difficult to verify whether the job exists.",
        action: "Request the legal company name and confirm it through official sources.",
        severity: "medium"
      },
      14
    );
  } else {
    addPositive("A company name was provided, which makes independent verification easier.", 4);
  }

  const wordCount = description.split(/\s+/).filter(Boolean).length;
  const hasResponsibilities = includesAny(description, [/\bresponsibilit(y|ies)\b/, /\brequirements?\b/, /\bqualification(s)?\b/, /\bexperience\b/, /\bskills?\b/]);
  if (wordCount < 35) {
    addFinding(
      {
        title: "Job description is too thin",
        why: "Very short postings often leave out responsibilities, qualifications, or company context.",
        action: "Ask for a complete job description before sharing personal information.",
        severity: "medium"
      },
      12
    );
  } else if (hasResponsibilities) {
    addPositive("The job description includes role details such as requirements, skills, or responsibilities.", 8);
  }

  if (includesAny(description, [/\bdear candidate\b/, /\b100%\s*guaranteed\b/, /\bearn\s*(from|at)\s*home\b/, /\bwork\s*only\s*\d+\s*hours\b/, /\btyping\s*job\b.*\bhigh\s*income\b/])) {
    addFinding(
      {
        title: "Suspicious wording pattern",
        why: "Generic or overly promotional wording can signal a copied or low-quality scam posting.",
        action: "Search exact phrases from the posting online and verify the company listing.",
        severity: "medium"
      },
      12
    );
  }

  if (!data.recruiterEmail.trim()) {
    addFinding(
      {
        title: "Recruiter email missing",
        why: "Without a recruiter email, it is harder to verify whether the contact belongs to the company.",
        action: "Ask for an official recruiter email address before moving forward.",
        severity: "medium"
      },
      8
    );
  } else if (!emailDomain) {
    addFinding(
      {
        title: "Recruiter email format looks invalid",
        why: "A malformed email address cannot be reliably checked against the company.",
        action: "Request communication from a valid official company email.",
        severity: "medium"
      },
      12
    );
  } else if (freeEmailDomains.includes(emailDomain)) {
    addFinding(
      {
        title: "Recruiter uses a personal email domain",
        why: "Recruiters for established companies usually contact candidates from official business domains.",
        action: "Verify the recruiter on LinkedIn and contact the company directly.",
        severity: "medium"
      },
      16
    );
  } else if (emailMatchesCompany) {
    addPositive("The recruiter email domain appears to match the company name.", 12);
  } else {
    addFinding(
      {
        title: "Recruiter email does not clearly match the company",
        why: "A mismatched email domain can indicate impersonation or an unofficial recruiter.",
        action: "Confirm the recruiter through the company website or official HR contact.",
        severity: "high"
      },
      20
    );
  }

  if (!data.applicationUrl.trim()) {
    addFinding(
      {
        title: "Application URL missing",
        why: "A verifiable application link helps confirm whether the role exists on an official hiring channel.",
        action: "Look for the role on the company careers page before applying.",
        severity: "medium"
      },
      8
    );
  } else if (!applicationDomain) {
    addFinding(
      {
        title: "Application URL format looks invalid",
        why: "Invalid or unclear links make it harder to know where your information is going.",
        action: "Do not submit personal details until you have a valid official application link.",
        severity: "high"
      },
      18
    );
  } else if (suspiciousDomains.some((suffix) => applicationDomain.endsWith(suffix))) {
    addFinding(
      {
        title: "Suspicious application domain",
        why: "Low-trust or unrelated domains are often used to collect applicant data outside official channels.",
        action: "Avoid the link and search for the opening on the company careers page.",
        severity: "high"
      },
      24
    );
  } else if (applicationIsKnownForCompany || applicationMatchesCompany || applicationIsTrusted) {
    addPositive("The application link appears to use an official or commonly trusted hiring domain.", 14);
  } else {
    addFinding(
      {
        title: "Application domain needs verification",
        why: "The application link does not clearly match the company name or a common hiring platform.",
        action: "Confirm the URL from the company careers page before entering personal information.",
        severity: "medium"
      },
      14
    );
  }

  if (applicationIsKnownForCompany && knownDomains.length > 0) {
    addPositive(`The application URL matches a known domain for ${companyName}.`, 10);
  }

  const finalScore = clampScore(score);
  const level = riskLevel(finalScore);
  const actions = findings.length
    ? Array.from(new Set(findings.map((finding) => finding.action))).slice(0, 5)
    : [
        "Continue through the official application link.",
        "Keep personal documents private until you are sure the employer is legitimate.",
        "Save a copy of the job posting and recruiter details for your records."
      ];

  return {
    score: finalScore,
    level,
    indicators: findings.map(({ title, why, severity }) => ({ title, why, severity })),
    recommendations: actions,
    findings,
    positives,
    actions,
    summary:
      findings.length > 0
        ? `JobLens found ${findings.length} risk signal${findings.length === 1 ? "" : "s"} and ${positives.length} trust signal${positives.length === 1 ? "" : "s"} in the submitted details.`
        : "JobLens did not find major scam indicators in the submitted details, but you should still verify the employer before sharing sensitive information."
  };
}

function scoreClasses(level: RiskLevel) {
  if (level === "HIGH") {
    return {
      border: "border-red-200",
      panel: "bg-red-50",
      text: "text-red-700",
      badge: "bg-red-600 text-white"
    };
  }

  if (level === "MEDIUM") {
    return {
      border: "border-amber-200",
      panel: "bg-amber-50",
      text: "text-amber-700",
      badge: "bg-amber-500 text-white"
    };
  }

  return {
    border: "border-emerald-200",
    panel: "bg-emerald-50",
    text: "text-emerald-700",
    badge: "bg-emerald-600 text-white"
  };
}

function findingClasses(severity: Severity) {
  if (severity === "high") return "border-red-200 bg-red-50/70 text-red-800";
  if (severity === "medium") return "border-amber-200 bg-amber-50/70 text-amber-800";
  return "border-emerald-200 bg-emerald-50/70 text-emerald-800";
}

export default function HomePage() {
  const [screen, setScreen] = useState<Screen>("home");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [formData, setFormData] = useState<JobFormData>(emptyForm);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);

  function updateField(field: keyof JobFormData, value: string) {
    setFormData((current) => ({ ...current, [field]: value }));
    if (error) setError("");
  }

  function analyzeSubmittedJob() {
    if (!formData.jobDescription.trim() || !formData.companyName.trim()) {
      setError("Add at least the job description and company name to run the mock analysis.");
      return;
    }

    setIsLoading(true);
    setError("");

    window.setTimeout(() => {
      const submittedInput = {
        jobDescription: formData.jobDescription,
        companyName: formData.companyName,
        recruiterEmail: formData.recruiterEmail,
        applicationUrl: formData.applicationUrl
      };
      const result = analyzeJob(submittedInput);

      console.log("FORM INPUT:", submittedInput);
      console.log("ANALYSIS RESULT:", result);

      setAnalysisResult(result);
      setIsLoading(false);
      setScreen("results");
      window.scrollTo({ top: 0, behavior: "smooth" });
    }, 900);
  }

  function analyzeAnotherJob() {
    setFormData(emptyForm);
    setAnalysisResult(null);
    setError("");
    setScreen("analyze");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const result = analysisResult ?? analyzeJob(formData);
  const scoreStyle = scoreClasses(result.level);

  return (
    <main className="min-h-screen bg-slate-50 text-slate-950">
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
        <nav className="container flex h-16 items-center justify-between">
          <button
            className="flex items-center gap-3 text-left"
            onClick={() => setScreen("home")}
            type="button"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary text-white shadow-sm">
              <ShieldCheck className="h-5 w-5" />
            </span>
            <span>
              <span className="block text-lg font-bold leading-none">JobLens</span>
              <span className="text-xs text-muted-foreground">Recruitment scam detection</span>
            </span>
          </button>

          <div className="flex items-center gap-2">
            <Button
              className="hidden sm:inline-flex"
              onClick={() => setScreen("home")}
              type="button"
              variant={screen === "home" ? "secondary" : "ghost"}
            >
              Home
            </Button>
            <Button
              onClick={() => setScreen("analyze")}
              type="button"
              variant={screen === "analyze" ? "secondary" : "outline"}
            >
              Analyze Job
            </Button>
          </div>
        </nav>
      </header>

      {screen === "home" && (
        <>
          <section className="container grid min-h-[calc(100vh-4rem)] items-center gap-10 py-12 lg:grid-cols-[minmax(0,1fr)_420px] lg:py-16">
            <div className="max-w-3xl">
              <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-blue-100 bg-blue-50 px-3 py-1 text-sm font-semibold text-primary">
                <ShieldAlert className="h-4 w-4" />
                JobLens
              </p>
              <h1 className="text-4xl font-bold tracking-normal text-slate-950 sm:text-5xl lg:text-6xl">
                See beyond the job posting.
              </h1>
              <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600">
                Analyze job opportunities for potential recruitment scam indicators before you apply.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Button className="h-12 px-6 text-base" onClick={() => setScreen("analyze")} type="button">
                  Analyze a Job
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <Card className="rounded-xl border-slate-200 bg-white shadow-xl shadow-slate-200/70">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BriefcaseBusiness className="h-5 w-5 text-primary" />
                  Rule-based scan
                </CardTitle>
                <CardDescription>Deterministic mock analysis for a suspicious remote role</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="rounded-lg border border-red-200 bg-red-50 p-5">
                  <p className="text-sm font-semibold text-red-700">Example Risk Score</p>
                  <div className="mt-2 flex items-end justify-between gap-4">
                    <p className="text-4xl font-bold text-red-700">High</p>
                    <span className="rounded-full bg-red-600 px-3 py-1 text-xs font-bold text-white">
                      EXPLAINABLE
                    </span>
                  </div>
                </div>
                <div className="space-y-3">
                  {sampleWarnings.map((warning) => (
                    <div key={warning.title} className="flex gap-3 rounded-lg border border-slate-200 p-3">
                      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
                      <div>
                        <p className="text-sm font-semibold">{warning.title}</p>
                        <p className="mt-1 text-xs leading-5 text-muted-foreground">{warning.text}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </section>

          <section className="border-y border-slate-200 bg-white">
            <div className="container py-14">
              <div className="max-w-2xl">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">How it works</p>
                <h2 className="mt-2 text-3xl font-bold text-slate-950">Submit, analyze, decide.</h2>
              </div>
              <div className="mt-8 grid gap-4 md:grid-cols-3">
                {steps.map((step) => (
                  <Card key={step.title} className="rounded-xl border-slate-200 bg-white shadow-sm">
                    <CardHeader>
                      <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-blue-50 text-primary">
                        <step.icon className="h-5 w-5" />
                      </span>
                      <CardTitle>{step.title}</CardTitle>
                      <CardDescription className="leading-6">{step.text}</CardDescription>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        </>
      )}

      {screen === "analyze" && (
        <section className="container py-10 sm:py-14">
          <div className="mx-auto max-w-4xl">
            <div className="mb-8 max-w-2xl">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">Analyze a job</p>
              <h1 className="mt-2 text-3xl font-bold text-slate-950 sm:text-4xl">
                Check a job opportunity before you apply.
              </h1>
              <p className="mt-3 leading-7 text-slate-600">
                Paste the details you have. This prototype uses deterministic rules now, and can later be replaced by an AI model.
              </p>
            </div>

            <Card className="rounded-xl border-slate-200 bg-white shadow-xl shadow-slate-200/70">
              <CardHeader className="border-b border-slate-100">
                <CardTitle>Job analysis form</CardTitle>
                <CardDescription>Required fields are marked with an asterisk.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5 pt-7">
                <div className="space-y-2">
                  <Label htmlFor="jobDescription">Job description *</Label>
                  <Textarea
                    className="min-h-52 resize-y rounded-lg border-slate-300 bg-white"
                    id="jobDescription"
                    onChange={(event) => updateField("jobDescription", event.target.value)}
                    placeholder="Paste the full job description, recruiter message, salary details, and any application instructions..."
                    value={formData.jobDescription}
                  />
                </div>

                <div className="grid gap-5 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="companyName">Company name *</Label>
                    <Input
                      className="rounded-lg border-slate-300 bg-white"
                      id="companyName"
                      onChange={(event) => updateField("companyName", event.target.value)}
                      placeholder="e.g., Amazon"
                      value={formData.companyName}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="recruiterEmail">Recruiter email</Label>
                    <Input
                      className="rounded-lg border-slate-300 bg-white"
                      id="recruiterEmail"
                      onChange={(event) => updateField("recruiterEmail", event.target.value)}
                      placeholder="recruiter@company.com"
                      type="email"
                      value={formData.recruiterEmail}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="applicationUrl">Application URL</Label>
                  <Input
                    className="rounded-lg border-slate-300 bg-white"
                    id="applicationUrl"
                    onChange={(event) => updateField("applicationUrl", event.target.value)}
                    placeholder="https://amazon.jobs/en/jobs/..."
                    type="url"
                    value={formData.applicationUrl}
                  />
                </div>

                {error && (
                  <div className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-medium text-amber-800">
                    {error}
                  </div>
                )}

                <div className="flex flex-col gap-3 border-t border-slate-100 pt-5 sm:flex-row sm:items-center sm:justify-between">
                  <p className="text-sm text-muted-foreground">
                    No data is sent anywhere in this prototype.
                  </p>
                  <Button className="h-12 px-6 text-base" disabled={isLoading} onClick={analyzeSubmittedJob} type="button">
                    {isLoading ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        Analyze Job
                        <ArrowRight className="h-4 w-4" />
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {screen === "results" && (
        <section className="container py-10 sm:py-14">
          <div className="mx-auto max-w-5xl">
            <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">Rule-based result</p>
                <h1 className="mt-2 text-3xl font-bold text-slate-950 sm:text-4xl">Analysis complete</h1>
              </div>
              <Button onClick={analyzeAnotherJob} type="button" variant="outline">
                <RotateCcw className="h-4 w-4" />
                Analyze Another Job
              </Button>
            </div>

            <div className="grid gap-5 lg:grid-cols-[320px_minmax(0,1fr)]">
              <Card className={`rounded-xl bg-white shadow-xl shadow-slate-200/70 ${scoreStyle.border}`}>
                <CardHeader>
                  <CardTitle>Risk Score</CardTitle>
                  <CardDescription>Based on submitted job details</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className={`rounded-xl p-6 text-center ${scoreStyle.panel}`}>
                    <p className={`text-5xl font-bold ${scoreStyle.text}`}>{result.score}/100</p>
                    <p className={`mt-3 inline-flex rounded-full px-4 py-1 text-sm font-bold ${scoreStyle.badge}`}>
                      {result.level} RISK
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="rounded-xl border-slate-200 bg-white shadow-sm">
                <CardHeader>
                  <CardTitle>Detected warning signs</CardTitle>
                  <CardDescription>{result.summary}</CardDescription>
                </CardHeader>
                <CardContent className="grid gap-3">
                  {result.indicators.length > 0 ? (
                    result.indicators.map((indicator) => (
                      <div key={`${indicator.title}-${indicator.why}`} className={`rounded-lg border p-4 ${findingClasses(indicator.severity)}`}>
                        <div className="flex gap-3">
                          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" />
                          <div>
                            <p className="font-semibold">{indicator.title}</p>
                            <p className="mt-1 text-sm leading-6 opacity-85">{indicator.why}</p>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-emerald-800">
                      <div className="flex gap-3">
                        <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0" />
                        <div>
                          <p className="font-semibold">No major warning signs detected</p>
                          <p className="mt-1 text-sm leading-6 opacity-85">
                            The submitted details look relatively consistent for this prototype&apos;s rule set.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="mt-5 grid gap-5 lg:grid-cols-2">
              <Card className="rounded-xl border-slate-200 bg-white shadow-sm">
                <CardHeader>
                  <CardTitle>Why JobLens flagged this</CardTitle>
                  <CardDescription>Explainable rules used in this prototype</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 text-sm leading-6 text-slate-600">
                  <p>{result.summary}</p>
                  {result.positives.length > 0 && (
                    <div className="rounded-lg border border-blue-100 bg-blue-50 p-4">
                      <p className="mb-2 flex items-center gap-2 font-semibold text-blue-800">
                        <Info className="h-4 w-4" />
                        Trust signals found
                      </p>
                      <ul className="space-y-2">
                        {result.positives.map((positive) => (
                          <li key={positive} className="flex gap-2 text-blue-800/80">
                            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
                            <span>{positive}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="rounded-xl border-slate-200 bg-white shadow-sm">
                <CardHeader>
                  <CardTitle>Recommended actions</CardTitle>
                  <CardDescription>Practical next steps based on the detected signals</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {result.recommendations.map((item) => (
                      <li key={item} className="flex gap-3 text-sm leading-6 text-slate-600">
                        <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      )}
    </main>
  );
}
